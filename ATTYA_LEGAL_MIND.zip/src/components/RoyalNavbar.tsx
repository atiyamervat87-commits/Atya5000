import React from 'react';
import {
  Scale,
  MessageSquare,
  Lock,
  Briefcase,
  Smartphone,
  ScrollText,
  UserCheck,
  Home,
  Crown,
  BookOpen,
  Globe,
  History,
  Languages,
  BarChart3,
  GitBranch,
} from 'lucide-react';
import { UserRole } from '../types/office';

interface RoyalNavbarProps {
  currentScreen: 'home' | 'public_consultation' | 'private_consultation' | 'office_management' | 'legal_history' | 'logic_chain';
  setCurrentScreen: (screen: 'home' | 'public_consultation' | 'private_consultation' | 'office_management' | 'legal_history' | 'logic_chain') => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onOpenCharter: () => void;
  onOpenAndroidModal: () => void;
  onOpenGlossary?: () => void;
  onOpenSmartSearch?: () => void;
  onOpenMillionVocab?: () => void;
  onOpenKnowledgeLibrary?: () => void;
  onOpenLanguageSettings?: () => void;
}

export const RoyalNavbar: React.FC<RoyalNavbarProps> = ({
  currentScreen,
  setCurrentScreen,
  userRole,
  setUserRole,
  onOpenCharter,
  onOpenAndroidModal,
  onOpenGlossary,
  onOpenSmartSearch,
  onOpenMillionVocab,
  onOpenKnowledgeLibrary,
  onOpenLanguageSettings,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#2B1914]/95 border-b border-[#D4AF37]/30 backdrop-blur-md shadow-lg shadow-black/40">
      {/* Top Royal Brand Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 border-b border-[#D4AF37]/15">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentScreen('home')}
            className="flex items-center gap-2.5 group cursor-pointer text-right"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37]/25 via-[#3A241B] to-[#1f120e] border border-[#D4AF37]/50 flex items-center justify-center shadow-md shadow-black/50 group-hover:border-[#E7C779] transition-all">
              <Scale className="w-5 h-5 text-[#D4AF37] group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base sm:text-lg font-bold font-amiri text-[#F5E5BD] tracking-wide">
                  عبقرينو — المستشار عطيه الهلباوي
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#E7C779] border border-[#D4AF37]/35 font-mono font-semibold">
                  المنصة الملكية
                </span>
              </div>
              <p className="text-[11px] text-[#F5E5BD]/60 hidden sm:block">
                محامٍ بالنقض والدستورية العليا • إدارة المكتب والاستشارات القضائية
              </p>
            </div>
          </button>
        </div>

        {/* Action Controls & Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {/* User Role Selector */}
          <div className="flex items-center gap-1 p-1 rounded-lg bg-[#1f120e] border border-[#D4AF37]/25 text-xs">
            <span className="text-[10px] text-[#F5E5BD]/60 px-1.5 flex items-center gap-1">
              <UserCheck className="w-3 h-3 text-[#D4AF37]" />
              الصلاحية:
            </span>
            <button
              onClick={() => setUserRole('owner')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                userRole === 'owner'
                  ? 'bg-[#D4AF37] text-[#2B1914] shadow-sm'
                  : 'text-[#F5E5BD]/70 hover:text-white'
              }`}
            >
              المالك
            </button>
            <button
              onClick={() => setUserRole('staff')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                userRole === 'staff'
                  ? 'bg-[#D4AF37] text-[#2B1914] shadow-sm'
                  : 'text-[#F5E5BD]/70 hover:text-white'
              }`}
            >
              الموظف
            </button>
          </div>

          {/* Quick Subscription Plan Status Indicator */}
          <button
            onClick={() => setCurrentScreen('office_management')}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#1f120e] hover:bg-[#3A241B] text-[#E7C779] border border-[#D4AF37]/35 text-xs font-semibold cursor-pointer transition shadow-sm"
            title="خطة التجربة الملكية النشطة (شهر مجاني)"
          >
            <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>شهر مجاني (نشط ✓)</span>
          </button>

          {/* Language & Dialect Settings Button */}
          {onOpenLanguageSettings && (
            <button
              onClick={onOpenLanguageSettings}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1f120e] hover:bg-[#3A241B] text-[#E7C779] border border-[#D4AF37]/35 text-xs font-semibold transition cursor-pointer shadow-sm"
              title="إعدادات اللغة واللهجات والكشف التلقائي"
            >
              <Languages className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden lg:inline">إعدادات اللغة</span>
            </button>
          )}

          {/* Million Vocabulary & Frequency Chart Button */}
          {onOpenMillionVocab && (
            <button
              onClick={onOpenMillionVocab}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#3A241B] to-[#2B1914] hover:bg-[#3A241B] text-[#E7C779] border border-[#D4AF37]/40 text-xs font-bold transition cursor-pointer shadow-sm"
              title="فحص المعجم اللغوي وتوزيع الترددات وفلك المليون مصطلح"
            >
              <BarChart3 className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden xl:inline">المعجم المليوني والرسم البياني</span>
              <span className="xl:hidden">المعجم المليوني</span>
            </button>
          )}

          {/* Multi-Million Book Knowledge Library Button */}
          {onOpenKnowledgeLibrary && (
            <button
              onClick={onOpenKnowledgeLibrary}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#2B1914] via-[#351d16] to-[#1f120e] text-[#F5E5BD] hover:text-white border border-[#D4AF37]/40 text-xs font-bold transition cursor-pointer shadow-sm"
              title="مكتبة المعرفة الإنسانية المليونية (1.39M+ مجلد ومخطوطة)"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden sm:inline">مكتبة المعرفة (ملايين الكتب)</span>
            </button>
          )}

          {/* Smart Legal Grounded Search Button */}
          {onOpenSmartSearch && (
            <button
              onClick={onOpenSmartSearch}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-950 via-[#2B1914] to-amber-950 text-emerald-300 hover:text-emerald-200 border border-emerald-500/50 text-xs font-bold transition cursor-pointer shadow-sm shadow-emerald-950/40"
              title="بحث ذكي في الجريدة الرسمية وأحكام محكمة النقض الحديثة عبر Google Grounding"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>الجريدة الرسمية والنقض (بحث ذكي)</span>
            </button>
          )}

          {/* Legal Glossary Button */}
          {onOpenGlossary && (
            <button
              onClick={onOpenGlossary}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1f120e] hover:bg-[#3A241B] text-[#E7C779] border border-[#D4AF37]/35 text-xs font-semibold transition cursor-pointer shadow-sm"
              title="معجم المصطلحات والمفاهيم القانونية المصرية"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>معجم المصطلحات</span>
            </button>
          )}

          {/* Android APK Modal Button */}
          <button
            onClick={onOpenAndroidModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#D4AF37]/20 to-[#3A241B] hover:from-[#D4AF37]/30 hover:to-[#3A241B]/80 text-[#E7C779] border border-[#D4AF37]/40 text-xs font-medium transition cursor-pointer shadow-sm"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="font-semibold">تطبيق Android (APK)</span>
          </button>

          {/* Charter Button */}
          <button
            onClick={onOpenCharter}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1f120e] hover:bg-[#3A241B] text-[#F5E5BD]/80 hover:text-[#F5E5BD] border border-[#D4AF37]/20 text-xs transition cursor-pointer"
          >
            <ScrollText className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden sm:inline">الوثيقة التأسيسية</span>
          </button>
        </div>
      </div>

      {/* Main Units Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-2 space-x-reverse overflow-x-auto py-2 no-scrollbar">
          <button
            onClick={() => setCurrentScreen('home')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
              currentScreen === 'home'
                ? 'bg-[#D4AF37] text-[#2B1914] shadow-md shadow-black/40'
                : 'text-[#F5E5BD]/75 hover:bg-[#3A241B] hover:text-[#F5E5BD]'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>الشاشة الرئيسية (الاستقبال)</span>
          </button>

          <button
            onClick={() => setCurrentScreen('public_consultation')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
              currentScreen === 'public_consultation'
                ? 'bg-[#D4AF37] text-[#2B1914] shadow-md shadow-black/40'
                : 'text-[#F5E5BD]/75 hover:bg-[#3A241B] hover:text-[#F5E5BD]'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>الوحدة الأولى: الاستشارة العامة</span>
          </button>

          <button
            onClick={() => setCurrentScreen('private_consultation')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
              currentScreen === 'private_consultation'
                ? 'bg-[#D4AF37] text-[#2B1914] shadow-md shadow-black/40'
                : 'text-[#F5E5BD]/75 hover:bg-[#3A241B] hover:text-[#F5E5BD]'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>الوحدة الثانية: الاستشارة الخاصة (200 ج.م)</span>
          </button>

          <button
            onClick={() => setCurrentScreen('office_management')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
              currentScreen === 'office_management'
                ? 'bg-[#D4AF37] text-[#2B1914] shadow-md shadow-black/40'
                : 'text-[#F5E5BD]/75 hover:bg-[#3A241B] hover:text-[#F5E5BD]'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>الوحدة الثالثة: برنامج إدارة المحاماة</span>
          </button>

          <button
            onClick={() => setCurrentScreen('legal_history')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
              currentScreen === 'legal_history'
                ? 'bg-[#D4AF37] text-[#2B1914] shadow-md shadow-black/40'
                : 'text-[#F5E5BD]/75 hover:bg-[#3A241B] hover:text-[#F5E5BD]'
            }`}
          >
            <History className="w-4 h-4" />
            <span>سجل القضايا والمسودات</span>
          </button>

          <button
            onClick={() => setCurrentScreen('logic_chain')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
              currentScreen === 'logic_chain'
                ? 'bg-[#D4AF37] text-[#2B1914] shadow-md shadow-black/40'
                : 'text-[#F5E5BD]/75 hover:bg-[#3A241B] hover:text-[#F5E5BD]'
            }`}
          >
            <GitBranch className="w-4 h-4 text-[#D4AF37]" />
            <span>شجرة الاستدلال (LogicChain)</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
