import React, { useEffect, useState } from 'react';
import {
  Scale,
  MessageSquare,
  Lock,
  Briefcase,
  ChevronLeft,
  ShieldCheck,
  Award,
  Clock,
  Phone,
  CreditCard,
  FileText,
  Users,
  CheckCircle2,
  Sparkles,
  Cpu,
  Layers,
  Download,
  History,
  BookOpen,
  BarChart3,
  Activity,
} from 'lucide-react';

interface HomeScreenProps {
  onSelectUnit: (unit: 'public_consultation' | 'private_consultation' | 'office_management') => void;
  onOpenAndroidModal: () => void;
  onOpenHistory?: () => void;
  onOpenMillionVocab?: () => void;
  onOpenKnowledgeLibrary?: () => void;
  onOpenDiagnostics?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onSelectUnit,
  onOpenAndroidModal,
  onOpenHistory,
  onOpenMillionVocab,
  onOpenKnowledgeLibrary,
  onOpenDiagnostics,
}) => {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetch('/api/office/stats')
      .then((res) => res.json())
      .then((data) => setStats(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Royal Welcome Hero Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#2B1914] via-[#3A241B] to-[#1a0e0b] border-2 border-[#D4AF37]/40 shadow-2xl p-6 sm:p-10 text-[#F5E5BD]">
        {/* Subtle royal pattern ornament */}
        <div className="absolute -left-12 -top-12 w-64 h-64 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-[#E7C779]/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-4 max-w-3xl text-right">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/35 text-[#E7C779] text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>عبقرينو — المنظومة الملكية الذكية للمحاماة والاستشارات</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-amiri text-[#F5E5BD] leading-tight">
              مكتب المستشار عطيه الهلباوي
            </h1>

            <div className="text-[#D4AF37] font-semibold text-sm sm:text-base font-amiri">
              محامٍ بالنقض والدستورية العليا ومجلس الدولة • خبير الصياغات القضائية والعقود
            </div>

            <p className="text-sm sm:text-base text-[#F5E5BD]/80 leading-relaxed font-sans">
              أهلاً وسهلاً بكم في المنصة الملكية المتكاملة المخصصة لإدارة العمل القضائي وتقديم الاستشارات القانونية وفق أحدث التقنيات وأصول التقاليد القضائية المصرية العريقة، بموجب ترخيص نقابة المحامين العامة.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-[#F5E5BD]/70">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                <span>السرية المهنية المصونة</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#D4AF37]" />
                <span>أسانيد محكمة النقض والدستورية</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <Phone className="w-4 h-4 text-[#D4AF37]" />
                <span>المحفظة الرسمية: 01153747612</span>
              </span>
            </div>
          </div>

          <div className="shrink-0 flex flex-col items-center justify-center p-6 rounded-2xl bg-[#1f120e]/80 border border-[#D4AF37]/30 shadow-xl text-center space-y-3 min-w-[220px]">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#D4AF37] to-[#E7C779] flex items-center justify-center shadow-lg shadow-black/50 text-[#2B1914]">
              <Scale className="w-10 h-10" />
            </div>
            <div>
              <div className="font-bold font-amiri text-lg text-[#F5E5BD]">المستشار عطيه الهلباوي</div>
              <div className="text-[11px] text-[#D4AF37] font-mono">الرمز والختم القضائي</div>
            </div>
            <div className="text-[10px] text-[#F5E5BD]/60 border-t border-[#D4AF37]/20 pt-2 w-full">
              قيد نقابة المحامين: 48215
            </div>
          </div>
        </div>
      </div>

      {/* Special Feature Banner: MAGIC MIND Gen-2 Architectural Integration */}
      <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#2B1914] to-emerald-950/40 border border-[#D4AF37]/50 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1.5 text-right">
          <div className="flex items-center gap-2 text-xs font-bold text-[#D4AF37]">
            <Cpu className="w-4 h-4 text-[#E7C779]" />
            <span className="uppercase tracking-wider">مشروع هندسي مكتمل • MAGIC MIND Gen-2</span>
            <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono">
              552,704 معلمات محققة
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold font-amiri text-[#F5E5BD]">
            عقل المستشار عطيه الهلباوي المدمج (ATTYA LEGAL MIND)
          </h2>
          <p className="text-xs text-[#F5E5BD]/75 max-w-2xl leading-relaxed">
            تم دمج معمارية Transformer المستقلة (Decoder-only) بخط معالجة ثلاثي المراحل: التوليد الخام، وحارس الأمانة القضائية لمنع الهلوسة، والإجابة النهائية المعتمدة. كما تتوفر الحزمتان المضغوطتان للتنزيل الفوري مع بصمات SHA-256.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {onOpenDiagnostics && (
            <button
              onClick={onOpenDiagnostics}
              className="px-4 py-2.5 rounded-xl bg-[#2B1914] hover:bg-[#3A241B] text-[#E7C779] border border-[#D4AF37]/50 font-bold text-xs flex items-center gap-2 transition cursor-pointer"
              title="تشخيص عقل المستشار وحالة الروابط مع نماذج الذكاء الاصطناعي"
            >
              <Activity className="w-4 h-4 text-[#D4AF37]" />
              <span>فحص المحركات والتشخيص 🩺</span>
            </button>
          )}
          <button
            onClick={() => onSelectUnit('office_management')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-110 text-[#2B1914] font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
          >
            <Layers className="w-4 h-4" />
            <span>فتح استوديو MAGIC MIND والحزم</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Strategic Dual Pillars: Million Lexicon & Multi-Million Book Library */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pillar 1: Million Lexicon & Frequency Distribution */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-[#2B1914] to-[#1f120e] border border-[#D4AF37]/35 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#E7C779] border border-[#D4AF37]/30 font-bold">
                1,000,000 مصطلح
              </span>
              <span className="text-[11px] text-emerald-400 font-mono">10 أفلاك معرفية</span>
            </div>
            <h3 className="text-lg font-bold font-amiri text-[#F5E5BD] flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#D4AF37]" />
              <span>المعجم المليوني والتحليل البياني للترددات</span>
            </h3>
            <p className="text-xs text-[#F5E5BD]/70 leading-relaxed">
              فحص شامل لملف المعجم الأصلي (545 رمزاً) وتوزيع ترددات مصطلحات القانون المصري، بجانب معجم المليون مصطلح وتطبيقات قانون زيف اللغوي.
            </p>
          </div>

          <button
            onClick={() => onOpenMillionVocab && onOpenMillionVocab()}
            className="w-full py-2.5 rounded-xl bg-[#2e1a14] hover:bg-[#3d221a] border border-[#D4AF37]/40 text-xs font-bold text-[#E7C779] flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <BarChart3 className="w-4 h-4 text-[#D4AF37]" />
            <span>فتح الرسم البياني وفحص المعجم المليوني</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Pillar 2: Multi-Million Book Knowledge Library */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-[#2B1914] to-[#1a0e0b] border border-[#D4AF37]/35 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 font-bold">
                1,390,000+ مجلد
              </span>
              <span className="text-[11px] text-[#D4AF37] font-mono">12 حقلاً معرفياً</span>
            </div>
            <h3 className="text-lg font-bold font-amiri text-[#F5E5BD] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#D4AF37]" />
              <span>مكتبة المعرفة الإنسانية المليونية</span>
            </h3>
            <p className="text-xs text-[#F5E5BD]/70 leading-relaxed">
              فهرس أمهات المصنفات وشروح السنهوري والمصادر الفلسفية والتاريخية والطب الشرعي وعلوم الذكاء الاصطناعي مع توثيق وصيغ استشهاد محققة.
            </p>
          </div>

          <button
            onClick={() => onOpenKnowledgeLibrary && onOpenKnowledgeLibrary()}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-110 text-[#2B1914] text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-md"
          >
            <BookOpen className="w-4 h-4" />
            <span>تصفح مكتبة المعرفة (ملايين الكتب)</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* The Three Core Mandatory Units */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-[#D4AF37]/20 pb-3">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-amiri text-[#F5E5BD] flex items-center gap-2">
              <Award className="w-6 h-6 text-[#D4AF37]" />
              <span>الوحدات الرئيسية الثلاث للمنصة الملكية</span>
            </h2>
            <p className="text-xs text-[#F5E5BD]/60 mt-0.5">
              اختر الوحدة المطلوبة للبدء في الاستشارة أو إدارة قضايا وملفات المكتب
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Public Consultation */}
          <div className="group relative flex flex-col justify-between p-6 rounded-2xl bg-gradient-to-b from-[#2B1914] to-[#1f120e] border-2 border-[#D4AF37]/30 hover:border-[#D4AF37] transition-all shadow-xl hover:shadow-[#D4AF37]/10 space-y-5">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#2B1914] transition-all">
                <MessageSquare className="w-7 h-7" />
              </div>

              <div>
                <span className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider block mb-1">
                  الوحدة الأولى
                </span>
                <h3 className="text-xl font-bold font-amiri text-[#F5E5BD]">
                  غرفة الاستشارة العامة
                </h3>
              </div>

              <p className="text-xs text-[#F5E5BD]/75 leading-relaxed">
                غرفة استشارة فورية ومجانية لطرح الأسئلة القانونية العامة، مع إدخال نصي مباشر واسترجاع نصوص مواد القانون المصري ومبادئ محكمة النقض.
              </p>

              <div className="space-y-1.5 text-[11px] text-[#F5E5BD]/60 pt-2 border-t border-[#D4AF37]/15">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>إدخال نصي سريع وإرسال مباشر</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>أدوات متقدمة: نسخ، طباعة، وتصدير الرد</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>دعم كامل للغة العربية واتجاه RTL</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectUnit('public_consultation')}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:from-[#E7C779] hover:to-[#D4AF37] text-[#2B1914] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-black/40 group-hover:gap-3"
            >
              <span>دخول غرفة الاستشارة العامة</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Card 2: Private Consultation */}
          <div className="group relative flex flex-col justify-between p-6 rounded-2xl bg-gradient-to-b from-[#2B1914] to-[#1f120e] border-2 border-[#D4AF37]/50 hover:border-[#E7C779] transition-all shadow-xl hover:shadow-[#D4AF37]/15 space-y-5">
            <div className="absolute top-4 left-4 px-2.5 py-0.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#E7C779] text-[10px] font-bold font-mono">
              200 ج.م
            </div>

            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#D4AF37]/20 border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#2B1914] transition-all">
                <Lock className="w-7 h-7" />
              </div>

              <div>
                <span className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider block mb-1">
                  الوحدة الثانية • مشفرة وخاصة
                </span>
                <h3 className="text-xl font-bold font-amiri text-[#F5E5BD]">
                  بوابة الاستشارة الخاصة
                </h3>
              </div>

              <p className="text-xs text-[#F5E5BD]/75 leading-relaxed">
                جلسة استشارية خاصة وسرية مع المستشار عطيه الهلباوي مع التحقق من سداد الرسوم (200 جنيه)، وتشمل فتح الكاميرا المباشرة، والميكروفون الصوتي، وإرفاق المستندات.
              </p>

              <div className="space-y-1.5 text-[11px] text-[#F5E5BD]/60 pt-2 border-t border-[#D4AF37]/15">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>المحفظة الرسمية: <strong>01153747612</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>تشغيل الكاميرا المباشرة والتقاط الصور</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>إملاء صوتي باللغة العربية (Voice-to-Text) بدون استخدام اليدين</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>تسجيل صوتي وإرفاق ملفات PDF وDOCX والكاميرا المباشرة</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectUnit('private_consultation')}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E7C779] to-[#D4AF37] hover:brightness-110 text-[#2B1914] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-black/40 group-hover:gap-3"
            >
              <span>دخول بوابة الاستشارة الخاصة</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Card 3: Office Management */}
          <div className="group relative flex flex-col justify-between p-6 rounded-2xl bg-gradient-to-b from-[#2B1914] to-[#1f120e] border-2 border-[#D4AF37]/30 hover:border-[#D4AF37] transition-all shadow-xl hover:shadow-[#D4AF37]/10 space-y-5">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#2B1914] transition-all">
                <Briefcase className="w-7 h-7" />
              </div>

              <div>
                <span className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider block mb-1">
                  الوحدة الثالثة • النظام المتكامل
                </span>
                <h3 className="text-xl font-bold font-amiri text-[#F5E5BD]">
                  برنامج إدارة المحاماة
                </h3>
              </div>

              <p className="text-xs text-[#F5E5BD]/75 leading-relaxed">
                منظومة متكاملة وشاملة لإدارة قضايا المكتب، الموكلين، الجلسات، الأجندة، الحسابات والأتعاب، والمستندات، والتقارير الذكية باللغة العربية.
              </p>

              <div className="space-y-1.5 text-[11px] text-[#F5E5BD]/60 pt-2 border-t border-[#D4AF37]/15">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>خط أنابيب معالجة وهندسة البيانات القانونية المصرية (8 مراحل متكاملة)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>استوديو تدريب العقل المركزي والنموذج اللغوي الخاص بالمستشار</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>خطة التجربة الملكية المجانية (شهر كامل 30 يوماً) وإدارة الاشتراكات</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>16 قسماً تخصصياً لإدارة العمل القضائي ومكتبة العقود الذكية</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>نماذج عقود قانونية مصرية مع التعبئة التلقائية للبيانات</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>وحدة التقارير الذكية والنسخ الاحتياطي والطباعة الملكية</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectUnit('office_management')}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:from-[#E7C779] hover:to-[#D4AF37] text-[#2B1914] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-black/40 group-hover:gap-3"
            >
              <span>فتح برنامج إدارة المحاماة</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Legal History & Drafts Tracking Spotlight Card */}
      {onOpenHistory && (
        <div className="p-6 rounded-2xl bg-gradient-to-r from-[#2B1914] via-[#352119] to-[#1f120e] border border-[#D4AF37]/40 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-right">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shadow-inner shrink-0">
              <History className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg font-bold font-amiri text-[#F5E5BD]">
                  سجل القضايا والمسودات القضائية (Legal History Tracker)
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4AF37]/20 text-[#E7C779] border border-[#D4AF37]/40 font-mono font-semibold">
                  حفظ وتصدير تلقائي
                </span>
              </div>
              <p className="text-xs text-[#F5E5BD]/70 mt-1">
                تتبع استفساراتك الأخيرة، وتكييفات المسائل القضائية، ومسودات العقود والمذكرات المحررة في هذه الجلسة، مع إمكانية التصدير بصيغ (JSON / Markdown / TXT / طباعة رسمية).
              </p>
            </div>
          </div>

          <button
            onClick={onOpenHistory}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-105 text-[#2B1914] font-bold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer shadow-md shadow-black/40 whitespace-nowrap shrink-0"
          >
            <History className="w-4 h-4" />
            <span>فتح سجل الجلسة والمسودات</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Real-time Office Statistics Bar */}
      {stats && (
        <div className="p-6 rounded-2xl bg-[#1f120e] border border-[#D4AF37]/30 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#D4AF37]/20 pb-3">
            <h3 className="font-bold text-[#D4AF37] font-amiri text-base flex items-center gap-2">
              <Scale className="w-4 h-4" />
              <span>مؤشرات أداء المكتب الحالية (سجلات حقيقية وقابلة للتحقق)</span>
            </h3>
            <span className="text-[11px] text-[#F5E5BD]/60 font-mono">محدث لحظياً</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 text-center">
            <div className="p-3 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
              <span className="text-[10px] text-[#F5E5BD]/60 block">إجمالي القضايا</span>
              <span className="text-xl font-bold font-mono text-[#D4AF37]">{stats.totalCases}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
              <span className="text-[10px] text-[#F5E5BD]/60 block">القضايا المتداولة</span>
              <span className="text-xl font-bold font-mono text-[#E7C779]">{stats.activeCases}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
              <span className="text-[10px] text-[#F5E5BD]/60 block">الموكلين المسجلين</span>
              <span className="text-xl font-bold font-mono text-white">{stats.totalClients}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
              <span className="text-[10px] text-[#F5E5BD]/60 block">الجلسات القادمة</span>
              <span className="text-xl font-bold font-mono text-[#D4AF37]">{stats.upcomingHearings}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
              <span className="text-[10px] text-[#F5E5BD]/60 block">المحصل من الأتعاب</span>
              <span className="text-base sm:text-lg font-bold font-mono text-emerald-400">
                {stats.totalCollected.toLocaleString()} ج.م
              </span>
            </div>
            <div className="p-3 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
              <span className="text-[10px] text-[#F5E5BD]/60 block">المتبقي للتحصيل</span>
              <span className="text-base sm:text-lg font-bold font-mono text-amber-300">
                {stats.uncollectedFees.toLocaleString()} ج.م
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
