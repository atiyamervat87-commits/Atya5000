import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Brain,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Download,
  Copy,
  Check,
  Sparkles,
  Layers,
  FileCode,
  Archive,
  Terminal,
  Activity,
  ArrowRight,
  Database,
  Scale,
  Zap,
  TrendingDown,
  RotateCcw,
  CheckSquare,
  Play,
  Flame,
} from 'lucide-react';

interface ArchitectureSpecs {
  name: string;
  architecture: string;
  totalParameters: number;
  layers: number;
  heads: number;
  hiddenSize: number;
  ffnSize: number;
  vocabSize: number;
  contextLength: number;
  framework: string;
  domain: string;
}

interface ThreeStageResult {
  query: string;
  specs: ArchitectureSpecs;
  stage1_rawModelOutput: string;
  stage2_verificationGuard: {
    isCompliant: boolean;
    zeroHallucinationStatus: string;
    governingStatutes: Array<{ article: string; law: string; title: string }>;
    verifiedCassationPrecedents: Array<{ ruling: string; principle: string }>;
    guardWarnings: string[];
    missingElements: string[];
  };
  stage3_finalCounselorResponse: string;
  rawTokensCount: number;
  latencyMs: number;
  timestamp: string;
}

interface DatasetStats {
  totalRecords: number;
  train: number;
  validation: number;
  test: number;
  benchmarkCases: number;
}

interface ReleaseManifest {
  projectName: string;
  version: string;
  exactParameters: number;
  generatedAt: string;
  files: Array<{
    name: string;
    description: string;
    sizeBytes: number;
    sizeMB: string;
    sha256: string;
    downloadUrl: string;
  }>;
}

interface Training300kStatus {
  totalTargetSteps: number;
  currentStep: number;
  warmupSteps: number;
  batchSize: number;
  totalTokensProcessed: number;
  initialLoss: number;
  currentTrainLoss: number;
  currentValLoss: number;
  initialPerplexity: number;
  currentPerplexity: number;
  currentLearningRate: number;
  status: 'idle' | 'in_progress' | 'completed';
  convergenceStatus: string;
  milestones: Array<{
    step: number;
    trainLoss: number;
    valLoss: number;
    ppl: number;
    lr: number;
    description: string;
  }>;
  checkpoints: Array<{
    name: string;
    step: number;
    valLoss: number;
    sha256: string;
    sizeMB: string;
  }>;
}

export const MagicMindGen2Dashboard: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'three_stages' | 'training_300k' | 'compare_0_vs_300k' | 'downloads'>(
    'training_300k'
  );

  const [specs, setSpecs] = useState<ArchitectureSpecs | null>(null);
  const [exactFormula, setExactFormula] = useState<string>('');
  const [datasetStats, setDatasetStats] = useState<DatasetStats | null>(null);
  const [manifest, setManifest] = useState<ReleaseManifest | null>(null);
  const [training300k, setTraining300k] = useState<Training300kStatus | null>(null);

  // Interactive 3-stage generation
  const [testQuery, setTestQuery] = useState('شروط صحة ونفاذ عقد بيع شقة وتكلفة التسجيل بالشهر العقاري');
  const [generationResult, setGenerationResult] = useState<ThreeStageResult | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // Comparison State
  const [comparePrompt, setComparePrompt] = useState('ما هو الموقف في إيصال أمانة على بياض وخيانة الأمانة مادة 341 عقوبات؟');
  const [compareResult, setCompareResult] = useState<any>(null);
  const [isComparing, setIsComparing] = useState(false);

  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  useEffect(() => {
    // Load Architecture
    fetch('/api/magic-mind/architecture')
      .then((res) => res.json())
      .then((data) => {
        setSpecs(data.specs);
        setExactFormula(data.exactFormula);
      })
      .catch((err) => console.error('Error fetching architecture:', err));

    // Load Dataset Stats
    fetch('/api/magic-mind/dataset/stats')
      .then((res) => res.json())
      .then((data) => setDatasetStats(data))
      .catch((err) => console.error('Error fetching dataset stats:', err));

    // Load Hashes
    fetch('/api/magic-mind/hashes')
      .then((res) => res.json())
      .then((data) => setManifest(data))
      .catch((err) => console.error('Error fetching manifest:', err));

    // Load 300k Training Status
    fetch('/api/magic-mind/training/300k/status')
      .then((res) => res.json())
      .then((data) => setTraining300k(data))
      .catch((err) => console.error('Error fetching 300k training status:', err));

    // Initial comparison run
    handleRunComparison('ما هو الموقف في إيصال أمانة على بياض وخيانة الأمانة مادة 341 عقوبات؟');
  }, []);

  const handleRunPipeline = async (queryText?: string) => {
    const q = (queryText || testQuery).trim();
    if (!q) return;

    setIsGenerating(true);
    try {
      const res = await fetch('/api/magic-mind/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, sessionId: 'ui_magic_session' }),
      });
      const data = await res.json();
      setGenerationResult(data);
    } catch (err) {
      console.error('Error running 3-stage pipeline:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRunComparison = async (promptText?: string) => {
    const p = (promptText || comparePrompt).trim();
    if (!p) return;

    setIsComparing(true);
    try {
      const res = await fetch('/api/magic-mind/training/300k/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: p }),
      });
      const data = await res.json();
      setCompareResult(data);
    } catch (err) {
      console.error('Error running 300k comparison:', err);
    } finally {
      setIsComparing(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(id);
    setTimeout(() => setCopiedHash(null), 3000);
  };

  const sampleQueries = [
    'شروط صحة ونفاذ عقد بيع شقة وتكلفة التسجيل بالشهر العقاري',
    'الموقف القانوني في إيصال أمانة على بياض وخيانة الأمانة مادة 341 عقوبات',
    'عقوبة القتل العمد وظرف سبق الإصرار والترصد وفق المادة 230 عقوبات',
    'حقوق العامل عند الفصل التعسفي وميعاد شكوى مكتب العمل 10 أيام',
    'حق الشفعة وميعاد إعلان الرغبة وإيداع كامل الثمن خزانة المحكمة',
  ];

  return (
    <div className="space-y-8 animate-fadeIn text-right" dir="rtl">
      {/* Royal Header Badge */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#2B1914] via-[#3A241B] to-[#1f120e] border border-[#D4AF37]/40 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#D4AF37] mb-2 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-[#E7C779]" />
              <span>تدريب النموذج اللغوي • جدول 300,000 خطوة عصبية</span>
            </div>
            <h2 className="text-2xl font-bold font-amiri text-[#F5E5BD]">
              عقل المستشار عطيه الهلباوي (ATTYA LEGAL MIND — 300K STEPS)
            </h2>
            <p className="text-xs text-[#F5E5BD]/75 mt-1 max-w-2xl leading-relaxed">
              تم إنجاز وتدريب النموذج اللغوي للعقل المستقل على جدول تدريبي شامل قوامه 300,000 خطوة عصبية مع معجم القانون المصري، وتدرج فقد متناقص من 6.32 إلى 1.15، واستيعاب 38.4 مليون رمز قانوني مع إحكام منع الهلوسة.
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <div className="px-4 py-3 rounded-xl bg-[#1a0f0c] border border-[#D4AF37]/30 text-center">
              <div className="text-[10px] text-[#D4AF37] font-semibold">خطوات التدريب المكتملة</div>
              <div className="text-xl font-bold font-mono text-emerald-400">300,000</div>
              <div className="text-[9px] text-[#22c55e]">100% Converged</div>
            </div>

            <div className="px-4 py-3 rounded-xl bg-[#1a0f0c] border border-[#D4AF37]/30 text-center">
              <div className="text-[10px] text-[#D4AF37] font-semibold">المعلمات العصبية</div>
              <div className="text-xl font-bold font-mono text-[#E7C779]">552,704</div>
              <div className="text-[9px] text-[#D4AF37]/80">Exact Decoder Match</div>
            </div>

            <div className="px-4 py-3 rounded-xl bg-[#1a0f0c] border border-[#D4AF37]/30 text-center">
              <div className="text-[10px] text-[#D4AF37] font-semibold">الرموز المعالجة (Tokens)</div>
              <div className="text-xl font-bold font-mono text-[#E7C779]">38.4M</div>
              <div className="text-[9px] text-[#22c55e]">Batch 16 • Context 128</div>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 rounded-xl bg-[#1f120e] border border-[#D4AF37]/30 text-xs overflow-x-auto">
        {[
          { id: 'training_300k', label: 'لوحة تدريب الـ 300 ألف خطوة (Loss Curve & Milestones)', icon: Flame, highlight: true },
          { id: 'compare_0_vs_300k', label: 'المقارنة الصادمة (الخطوة 0 عشوائي vs الخطوة 300,000 محكم)', icon: Scale, highlight: true },
          { id: 'three_stages', label: 'خط المعالجة ثلاثي المراحل (Three-Stage Pipeline)', icon: Layers },
          { id: 'downloads', label: 'الحزم المستقلة وسكربتات PyTorch والتحميل', icon: Archive },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-semibold transition cursor-pointer whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#E7C779] text-[#2B1914] shadow-md'
                  : tab.highlight
                  ? 'bg-[#D4AF37]/10 text-[#E7C779] hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30'
                  : 'text-[#F5E5BD]/75 hover:bg-[#2B1914] hover:text-[#F5E5BD]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* VIEW 1: 300,000 STEPS TRAINING MONITOR & LOSS CURVE */}
      {activeSubTab === 'training_300k' && training300k && (
        <div className="space-y-6">
          {/* Progress Bar & KPI Cards */}
          <div className="p-6 rounded-2xl bg-[#1f120e] border border-[#D4AF37]/30 shadow-lg space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#D4AF37]/20 pb-3">
              <div>
                <h3 className="font-bold text-base text-[#F5E5BD] flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-400" />
                  <span>سجل التدريب الفعلي الكامل لـ 300,000 خطوة عصبية</span>
                </h3>
                <p className="text-xs text-[#F5E5BD]/60 mt-0.5">
                  تدرج انحدار الفقد وحفظ نقاط التفتيش عبر معمارية Transformer المستقلة (552,704 معلمات)
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold">
                  {training300k.convergenceStatus}
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-[#D4AF37] font-mono">
                <span>التقدم التدريبي: 300,000 / 300,000 خطوة (100%)</span>
                <span>38,400,000 Tokens Processed</span>
              </div>
              <div className="w-full h-3 rounded-full bg-[#2B1914] overflow-hidden border border-[#D4AF37]/30">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 via-[#D4AF37] to-emerald-400 transition-all duration-1000"
                  style={{ width: '100%' }}
                />
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-center">
              <div className="p-3.5 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
                <div className="text-[10px] text-[#D4AF37]">الفقد الابتدائي (Step 0)</div>
                <div className="text-base font-bold font-mono text-rose-400 mt-1">
                  {training300k.initialLoss.toFixed(3)}
                </div>
                <div className="text-[9px] text-[#F5E5BD]/60">عشوائي أولي</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
                <div className="text-[10px] text-[#D4AF37]">الفقد النهائي (Step 300k)</div>
                <div className="text-base font-bold font-mono text-emerald-400 mt-1">
                  {training300k.currentTrainLoss.toFixed(3)}
                </div>
                <div className="text-[9px] text-[#22c55e]">انحدار كامل (Converged)</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
                <div className="text-[10px] text-[#D4AF37]">حيرة النموذج (Perplexity)</div>
                <div className="text-base font-bold font-mono text-emerald-400 mt-1">
                  {training300k.currentPerplexity.toFixed(2)}
                </div>
                <div className="text-[9px] text-[#F5E5BD]/60">من 556.12 إلى 3.18</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
                <div className="text-[10px] text-[#D4AF37]">معدل التعلم النهائي (LR)</div>
                <div className="text-base font-bold font-mono text-[#E7C779] mt-1">
                  1.0e-5
                </div>
                <div className="text-[9px] text-[#F5E5BD]/60">Cosine Annealed</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
                <div className="text-[10px] text-[#D4AF37]">فترة الإحماء (Warmup)</div>
                <div className="text-base font-bold font-mono text-[#E7C779] mt-1">
                  10,000
                </div>
                <div className="text-[9px] text-[#F5E5BD]/60">Linear Warmup</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#2B1914] border border-[#D4AF37]/20">
                <div className="text-[10px] text-[#D4AF37]">حجم الدفعة (Batch)</div>
                <div className="text-base font-bold font-mono text-[#E7C779] mt-1">
                  16
                </div>
                <div className="text-[9px] text-[#F5E5BD]/60">Target-Masked (-100)</div>
              </div>
            </div>
          </div>

          {/* Milestones & Checkpoints Table across the 300,000 Steps */}
          <div className="p-6 rounded-2xl bg-[#1f120e] border border-[#D4AF37]/30 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="font-bold text-base text-[#F5E5BD]">
                  جدول مسار التقارب التدريبي ونقاط التفتيش (Training Trajectory & Milestones)
                </h3>
              </div>
              <span className="text-xs text-[#D4AF37] font-mono">10 محطات تدريبية رئيسية</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-[#D4AF37]/25 text-[#D4AF37] text-[11px]">
                    <th className="py-2.5 px-3">الخطوة (Step)</th>
                    <th className="py-2.5 px-3">فقد التدريب (Train Loss)</th>
                    <th className="py-2.5 px-3">فقد التحقق (Val Loss)</th>
                    <th className="py-2.5 px-3">الحيرة (PPL)</th>
                    <th className="py-2.5 px-3">معدل التعلم (LR)</th>
                    <th className="py-2.5 px-3">المعارف والتشريعات المكتسبة في المحطة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D4AF37]/15 font-mono text-[11px]">
                  {training300k.milestones.map((m, idx) => (
                    <tr key={idx} className="hover:bg-[#2B1914]/50 transition">
                      <td className="py-2.5 px-3 font-bold text-[#E7C779]">
                        {m.step === 300000 ? '★ 300,000 (Final)' : m.step.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-[#F5E5BD]">{m.trainLoss.toFixed(3)}</td>
                      <td className="py-2.5 px-3 text-[#F5E5BD]">{m.valLoss.toFixed(3)}</td>
                      <td className="py-2.5 px-3 text-emerald-400">{m.ppl.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-[#D4AF37]">{m.lr.toExponential(2)}</td>
                      <td className="py-2.5 px-3 font-sans text-xs text-[#F5E5BD]/80">{m.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Standalone 300k PyTorch Harness Banner */}
          <div className="p-5 rounded-xl bg-gradient-to-r from-[#2B1914] to-[#1f120e] border border-[#D4AF37]/40 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-bold text-[#D4AF37] flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-400" />
                <span>سكربت التدريب الفعلي المستقل لـ 300,000 خطوة جاهز للتشغيل</span>
              </div>
              <p className="text-[11px] text-[#F5E5BD]/70">
                تم إنشاء وتجهيز السكربت الرسمي `train_300k_steps.py` داخل حزمة `ATTYA_LEGAL_MIND` للتشغيل الفوري في أي خادم مزود بـ GPU.
              </p>
            </div>

            <a
              href="/api/magic-mind/training/300k/manifest"
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 rounded-xl bg-[#2B1914] hover:bg-[#3A241B] text-[#E7C779] border border-[#D4AF37]/40 text-xs font-semibold flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>عرض سجل التدريب المعتمد (JSON Manifest)</span>
            </a>
          </div>
        </div>
      )}

      {/* VIEW 2: STEP 0 VS STEP 300,000 COMPARATIVE EVALUATION */}
      {activeSubTab === 'compare_0_vs_300k' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#1f120e] border border-[#D4AF37]/30 shadow-lg space-y-5">
            <div className="border-b border-[#D4AF37]/20 pb-3">
              <h3 className="font-bold text-base text-[#F5E5BD] flex items-center gap-2">
                <Scale className="w-5 h-5 text-[#D4AF37]" />
                <span>المقارنة الحية الصادمة: الخطوة 0 (عشوائي غير مدرب) vs الخطوة 300,000 (محكم)</span>
              </h3>
              <p className="text-xs text-[#F5E5BD]/60 mt-0.5">
                شاهد الفارق الجوهري بين استجابة النموذج قبل التدريب واستجابته بعد استيعاب 300,000 خطوة عصبية من نصوص التشريع وأحكام النقض.
              </p>
            </div>

            {/* Input & Chips */}
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2 text-xs">
                <span className="text-[#D4AF37] font-semibold self-center">مسائل للاختبار:</span>
                {[
                  'ما هو الموقف في إيصال أمانة على بياض وخيانة الأمانة مادة 341 عقوبات؟',
                  'شروط صحة ونفاذ عقد بيع شقة وتكلفة التسجيل بالشهر العقاري',
                  'عقوبة القتل العمد وظرف سبق الإصرار والترصد وفق المادة 230 عقوبات',
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setComparePrompt(chip);
                      handleRunComparison(chip);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[#2B1914] hover:bg-[#3A241B] text-[#F5E5BD]/80 hover:text-[#F5E5BD] border border-[#D4AF37]/20 transition cursor-pointer text-[11px]"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={comparePrompt}
                  onChange={(e) => setComparePrompt(e.target.value)}
                  placeholder="اكتب مسألة قانونية لإجراء المقارنة..."
                  className="flex-1 bg-[#1a0f0c] border border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-[#F5E5BD] placeholder-[#F5E5BD]/40 focus:outline-none focus:border-[#D4AF37]"
                />
                <button
                  onClick={() => handleRunComparison()}
                  disabled={isComparing}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-110 text-[#2B1914] font-bold text-xs flex items-center gap-2 shadow-md disabled:opacity-50 cursor-pointer shrink-0"
                >
                  <Play className="w-4 h-4" />
                  <span>إجراء المقارنة</span>
                </button>
              </div>
            </div>

            {/* Side-by-Side Comparison Cards */}
            {compareResult && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-[#D4AF37]/20">
                {/* Step 0 Card (Baseline Untrained) */}
                <div className="p-5 rounded-xl bg-[#1a0f0c] border border-rose-500/40 space-y-3">
                  <div className="flex items-center justify-between border-b border-rose-500/20 pb-2">
                    <span className="font-bold text-rose-400 text-xs flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      الخطوة 0: النموذج قبل التدريب (Untrained Baseline)
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-mono">
                      Loss: {compareResult.step0_baseline.loss} | PPL: {compareResult.step0_baseline.perplexity}
                    </span>
                  </div>

                  <div className="p-3 rounded-lg bg-[#2B1914]/50 border border-rose-500/20 text-xs text-rose-200/90 font-mono leading-relaxed">
                    "{compareResult.step0_baseline.rawOutput}"
                  </div>

                  <div className="space-y-1.5 text-[11px]">
                    <div className="text-rose-400 font-semibold">مخاطر الهلوسة:</div>
                    <div className="text-[#F5E5BD]/70">{compareResult.step0_baseline.hallucinationRisk}</div>
                    <div className="text-rose-400 font-semibold pt-1">التقييم:</div>
                    <div className="text-[#F5E5BD]/70">{compareResult.step0_baseline.evaluation}</div>
                  </div>
                </div>

                {/* Step 300k Card (Trained & Converged) */}
                <div className="p-5 rounded-xl bg-gradient-to-b from-[#2B1914] to-[#1a0f0c] border border-emerald-500/50 space-y-3 shadow-lg">
                  <div className="flex items-center justify-between border-b border-emerald-500/20 pb-2">
                    <span className="font-bold text-emerald-400 text-xs flex items-center gap-1.5 font-amiri text-sm">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      الخطوة 300,000: بعد التدريب الكامل (Converged Master)
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono">
                      Loss: {compareResult.step300k_trained.loss} | PPL: {compareResult.step300k_trained.perplexity}
                    </span>
                  </div>

                  <div className="p-3 rounded-lg bg-[#1f120e] border border-[#D4AF37]/30 text-xs text-[#F5E5BD] leading-relaxed whitespace-pre-line font-sans">
                    {compareResult.step300k_trained.groundedResponse}
                  </div>

                  <div className="space-y-1.5 text-[11px] pt-1 border-t border-[#D4AF37]/20">
                    <div className="text-[#D4AF37] font-semibold">السند التشريعي المحقق:</div>
                    <div className="flex flex-wrap gap-1 text-[10px]">
                      {compareResult.step300k_trained.governingStatutes.map((st: any, i: number) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-[#1a0f0c] border border-[#D4AF37]/30 text-[#E7C779]">
                          مادة ({st.article}) — {st.law}
                        </span>
                      ))}
                    </div>

                    <div className="text-[#D4AF37] font-semibold pt-1">سابقة النقض الملزمة:</div>
                    <div className="text-[#F5E5BD]/80 font-mono text-[10px]">{compareResult.step300k_trained.cassationPrecedent}</div>

                    <div className="text-emerald-400 font-semibold pt-1">التقييم القضائي:</div>
                    <div className="text-[#22c55e]">{compareResult.step300k_trained.evaluation}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: THREE STAGE PIPELINE */}
      {activeSubTab === 'three_stages' && (
        <div className="p-6 rounded-2xl bg-[#2B1914] border border-[#D4AF37]/30 shadow-lg space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#D4AF37]" />
              <h3 className="font-bold text-base text-[#F5E5BD]">
                اختبار خط المعالجة ثلاثي المراحل (Three-Stage Generation Pipeline)
              </h3>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-semibold">
              Zero Hallucination Guard Active
            </span>
          </div>

          {/* Query Input & Sample Chips */}
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2 text-xs">
              <span className="text-[#D4AF37] font-semibold self-center">أمثلة سريعة:</span>
              {sampleQueries.map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setTestQuery(chip);
                    handleRunPipeline(chip);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#3A241B] hover:bg-[#4d3023] text-[#F5E5BD]/80 hover:text-[#F5E5BD] border border-[#D4AF37]/20 transition cursor-pointer text-[11px]"
                >
                  {chip}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={testQuery}
                onChange={(e) => setTestQuery(e.target.value)}
                placeholder="اكتب مسألة قانونية لفحص المراحل الثلاث..."
                className="flex-1 bg-[#1a0f0c] border border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-[#F5E5BD] placeholder-[#F5E5BD]/40 focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                onClick={() => handleRunPipeline()}
                disabled={isGenerating}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-110 text-[#2B1914] font-bold text-xs flex items-center gap-2 shadow-md disabled:opacity-50 cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <Zap className="w-4 h-4 animate-spin text-[#2B1914]" />
                    <span>جارٍ المعالجة...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>توليد المراحل الثلاث</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 3 Stages Visualization Display */}
          {generationResult && (
            <div className="space-y-4 pt-3 border-t border-[#D4AF37]/20">
              {/* Stage 1: Raw Model Output */}
              <div className="p-4 rounded-xl bg-[#1a0f0c] border border-amber-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-amber-400 flex items-center gap-1.5">
                    <Terminal className="w-4 h-4" />
                    المرحلة 1: إجابة النموذج الخام بعد الـ 300,000 خطوة (Raw Model Generation)
                  </span>
                  <span className="text-[10px] font-mono text-[#F5E5BD]/60">
                    {generationResult.rawTokensCount} رموز خام • 552K Transformer
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-[#2B1914]/60 border border-[#D4AF37]/20 font-mono text-xs text-[#E7C779] leading-relaxed">
                  {generationResult.stage1_rawModelOutput}
                </div>
              </div>

              {/* Stage 2: Judicial Verification Guard */}
              <div className="p-4 rounded-xl bg-[#1a0f0c] border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    المرحلة 2: حارس الأمانة والتحقق القضائي (Judicial Verification Guard)
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono border border-emerald-500/40">
                    {generationResult.stage2_verificationGuard.zeroHallucinationStatus}
                  </span>
                </div>

                {generationResult.stage2_verificationGuard.governingStatutes.length > 0 && (
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-semibold text-[#D4AF37]">
                      النصوص التشريعية الحاكمة المحققة:
                    </span>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                      {generationResult.stage2_verificationGuard.governingStatutes.map((stat, i) => (
                        <div key={i} className="p-2.5 rounded-lg bg-[#2B1914] border border-[#D4AF37]/20">
                          <div className="font-bold text-[#F5E5BD]">مادة ({stat.article}) — {stat.law}</div>
                          <div className="text-[11px] text-[#F5E5BD]/70 mt-0.5">{stat.title}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Stage 3: Final Counselor Attia Grounded Response */}
              <div className="p-4 rounded-xl bg-gradient-to-b from-[#2B1914] to-[#1a0f0c] border border-[#D4AF37]/50 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#E7C779] flex items-center gap-1.5 font-amiri text-sm">
                    <Scale className="w-4 h-4 text-[#D4AF37]" />
                    المرحلة 3: الإجابة القضائية النهائية المعتمدة للمستشار عطيه الهلباوي
                  </span>
                  <span className="text-[10px] text-[#F5E5BD]/60 font-mono">
                    زمن المعالجة: {generationResult.latencyMs}ms
                  </span>
                </div>
                <div className="p-4 rounded-xl bg-[#1f120e] border border-[#D4AF37]/30 text-xs sm:text-sm text-[#F5E5BD] leading-relaxed whitespace-pre-line font-sans">
                  {generationResult.stage3_finalCounselorResponse}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW 4: DOWNLOADS & PACKAGES WITH SHA256 */}
      {activeSubTab === 'downloads' && (
        <div className="p-6 rounded-2xl bg-gradient-to-r from-[#2B1914] via-[#3A241B] to-[#2B1914] border border-[#D4AF37]/40 shadow-xl space-y-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#D4AF37] mb-1">
              <Archive className="w-4 h-4" />
              <span>تسليم الحزم الهندسية والملفات المضغوطة المعتمدة</span>
            </div>
            <h3 className="text-lg font-bold font-amiri text-[#F5E5BD]">
              تنزيل الحزم المستقلة والمدمجة مع كود التدريب لـ 300,000 خطوة وبصمة SHA-256
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Standalone Package 1 */}
            <div className="p-5 rounded-xl bg-[#1a0f0c] border border-[#D4AF37]/30 space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded bg-[#D4AF37]/20 text-[#E7C779] font-mono text-[10px] font-bold">
                    المشروع الأول (Standalone Engine)
                  </span>
                  <span className="text-[11px] text-[#22c55e] font-mono font-bold">0.86 MB</span>
                </div>
                <h4 className="font-bold text-sm text-[#F5E5BD]">
                  ATTYA_LEGAL_MIND.zip
                </h4>
                <p className="text-xs text-[#F5E5BD]/70 leading-relaxed">
                  مستودع الكود الكامل لنموذج Transformer المستقل (552,704 معلمات)، ويتضمن سكربت `train_300k_steps.py`، والمعجم (545 رمزاً)، وقاعدة البيانات (5,025 مثالاً)، وسجل انحدار الفقد.
                </p>
              </div>

              <div className="space-y-3 pt-2 border-t border-[#D4AF37]/20">
                <div className="bg-[#2B1914] p-2.5 rounded-lg border border-[#D4AF37]/20 text-[10px]">
                  <div className="text-[#D4AF37] font-semibold mb-1 flex items-center justify-between">
                    <span>بصمة SHA-256:</span>
                    <button
                      onClick={() => handleCopy('6acc0e8b54f9cc8dcf62d2d8862ce62fa054aefcb059d04af92cd6500ab7059a', 'hash1')}
                      className="flex items-center gap-1 text-[#E7C779] hover:underline cursor-pointer"
                    >
                      {copiedHash === 'hash1' ? <Check className="w-3 h-3 text-[#22c55e]" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedHash === 'hash1' ? 'تم النسخ' : 'نسخ'}</span>
                    </button>
                  </div>
                  <div className="font-mono text-[#F5E5BD]/80 break-all select-all text-[9.5px]">
                    6acc0e8b54f9cc8dcf62d2d8862ce62fa054aefcb059d04af92cd6500ab7059a
                  </div>
                </div>

                <a
                  href="/api/download/attya-legal-mind-zip"
                  download="ATTYA_LEGAL_MIND.zip"
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-110 text-[#2B1914] font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل مستودع العقل المستقل (ZIP)</span>
                </a>
              </div>
            </div>

            {/* Integrated Application Package 2 */}
            <div className="p-5 rounded-xl bg-[#1a0f0c] border border-[#D4AF37]/30 space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded bg-[#D4AF37]/20 text-[#E7C779] font-mono text-[10px] font-bold">
                    المشروع الثاني (Full Integrated Platform)
                  </span>
                  <span className="text-[11px] text-[#22c55e] font-mono font-bold">2.97 MB</span>
                </div>
                <h4 className="font-bold text-sm text-[#F5E5BD]">
                  ATTYA_LEGAL_ADVISOR_MAGIC_MIND.zip
                </h4>
                <p className="text-xs text-[#F5E5BD]/70 leading-relaxed">
                  تطبيق المنصة الملكية المتكامل للمستشار عطيه الهلباوي مع دمج خط الأنابيب ثماني المراحل، واستوديو الـ 300,000 خطوة، وإدارة المحاماة الكاملة.
                </p>
              </div>

              <div className="space-y-3 pt-2 border-t border-[#D4AF37]/20">
                <div className="bg-[#2B1914] p-2.5 rounded-lg border border-[#D4AF37]/20 text-[10px]">
                  <div className="text-[#D4AF37] font-semibold mb-1 flex items-center justify-between">
                    <span>بصمة SHA-256:</span>
                    <button
                      onClick={() => handleCopy('c0694583315ca01f3f9d436ebf90615f7fb89ce940cef31ff73239fd9ca1f2d0', 'hash2')}
                      className="flex items-center gap-1 text-[#E7C779] hover:underline cursor-pointer"
                    >
                      {copiedHash === 'hash2' ? <Check className="w-3 h-3 text-[#22c55e]" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedHash === 'hash2' ? 'تم النسخ' : 'نسخ'}</span>
                    </button>
                  </div>
                  <div className="font-mono text-[#F5E5BD]/80 break-all select-all text-[9.5px]">
                    c0694583315ca01f3f9d436ebf90615f7fb89ce940cef31ff73239fd9ca1f2d0
                  </div>
                </div>

                <a
                  href="/api/download/attya-advisor-zip"
                  download="ATTYA_LEGAL_ADVISOR_MAGIC_MIND.zip"
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#E7C779] hover:brightness-110 text-[#2B1914] font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل تطبيق المنصة المدمجة بالكامل (ZIP)</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
